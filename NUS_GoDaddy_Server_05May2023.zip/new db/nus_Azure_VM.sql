-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 10, 2023 at 05:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nus`
--

-- --------------------------------------------------------

--
-- Table structure for table `clientcompanydata`
--

CREATE TABLE `clientcompanydata` (
  `id` int(11) NOT NULL,
  `parentcompany` varchar(255) NOT NULL,
  `clientcompany` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `serialno` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clientcompanydata`
--

INSERT INTO `clientcompanydata` (`id`, `parentcompany`, `clientcompany`, `country`, `serialno`) VALUES
(1, 'Testing', 'Qualesce India', 'Bahrain', 12),
(2, 'Testing', 'test1', 'India', 5),
(3, 'Qualesce INDIA', 'Qualesce India', 'Andorra', 4),
(4, 'TestParent', 'TestClient', 'India', 5),
(5, 'TestParent2', 'TestClient2', 'India', 1);

-- --------------------------------------------------------

--
-- Table structure for table `enter_trade`
--

CREATE TABLE `enter_trade` (
  `tradeId` int(11) NOT NULL,
  `parentId` varchar(50) DEFAULT NULL,
  `clientId` int(11) DEFAULT NULL,
  `supplycontractid` varchar(128) DEFAULT NULL,
  `mw` int(11) DEFAULT NULL,
  `mwh` varchar(30) DEFAULT NULL,
  `percentage` varchar(30) DEFAULT NULL,
  `tradevolume` varchar(50) DEFAULT NULL,
  `baseload` float(10,2) DEFAULT NULL,
  `effectiveprice` float(10,2) DEFAULT NULL,
  `trade` varchar(30) DEFAULT NULL,
  `tradevalue` varchar(20) DEFAULT NULL,
  `tradingId` int(11) DEFAULT NULL,
  `nustradeId` int(11) DEFAULT NULL,
  `tradeDate` varchar(30) DEFAULT NULL,
  `quartval` varchar(30) DEFAULT NULL,
  `tradequarvol` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enter_trade`
--

INSERT INTO `enter_trade` (`tradeId`, `parentId`, `clientId`, `supplycontractid`, `mw`, `mwh`, `percentage`, `tradevolume`, `baseload`, `effectiveprice`, `trade`, `tradevalue`, `tradingId`, `nustradeId`, `tradeDate`, `quartval`, `tradequarvol`) VALUES
(1, 'Qualesce', 1, 'Qualesce-elec-00005', 0, '', '10', '1200', 24.00, 20.00, 'Calendar Yearly', '2024', 2, 2, '2023-03-28', '', '12000'),
(2, 'Qualesce', 1, 'Qualesce-elec-00005', 0, '', '12', '1440', 34.00, 45.00, 'Calendar Yearly', '2024', 2, 2, '2023-03-28', '', '12000'),
(3, 'Qualesce', 1, 'Qualesce-elec-00006', 0, '', '15', '1800', 10.00, 20.00, 'Calendar Yearly', '2024', 5, 3, '2023-03-28', '', '12000'),
(4, 'Qualesce', 1, 'Qualesce-elec-00007', 0, '10', '', '10', 14.00, 23.00, 'Calendar Quarterly', '2023', 7, 9, '2023-03-28', 'q3', '3000'),
(5, 'Qualesce', 1, 'Qualesce-elec-00010', 10, '', '', '87840', 10.00, 12.00, 'Calendar Yearly', '2024', 15, 11, '2023-03-28', '', '12000'),
(6, 'Qualesce', 1, 'Qualesce-elec-00010', 10, '', '', '87840', 10.00, 12.00, 'Calendar Yearly', '2024', 15, 11, '2023-03-28', '', '12000'),
(7, 'Qualesce', 1, 'Qualesce-elec-00011', 10, '', '', '87840', 10.00, 12.00, 'Calendar Yearly', '2024', 18, 13, '2023-03-28', '', '1200000'),
(8, 'Testing', 2, 'test1-elec-00003', 0, '', '10', '1200', 100.00, 120.00, 'Calendar Yearly', '2023', 21, 15, '2023-03-29', '', '12000'),
(9, 'Testing', 2, 'test1-elec-00003', 0, '120', '', '120', 100.00, 120.00, 'Calendar Quarterly', '2023', 22, 62, '2023-03-29', 'q4', '3000'),
(10, 'Testing', 2, 'test1-elec-00003', 0, '', '90', '10800', 40.00, 50.00, 'Calendar Yearly', '2025', 21, 17, '2023-03-29', '', '12000'),
(11, 'Testing', 2, 'test1-elec-00003', 0, '400', '', '400', 23.00, 34.00, 'Calendar Quarterly', '2023', 22, 60, '2023-03-29', 'q2', '3000'),
(12, 'Testing', 2, 'test1-gas-00004', 0, '', '92', '110400', 12.00, 15.00, 'Calendar Yearly', '2024', 24, 18, '2023-03-29', '', '120000'),
(13, 'Testing', 2, 'test1-elec-00005', 10, '', '', '87600', 12.00, 15.00, 'Calendar Yearly', '2023', 30, 23, '2023-03-29', '', '12000'),
(14, 'Testing', 2, 'test1-elec-00005', 3, '', '', '6624', 23.00, 23.00, 'Calendar Quarterly', '2023', 31, 102, '2023-03-29', 'q4', '30000'),
(15, 'Testing', 2, 'test1-elec-00005', 10, '', '', '7200', 12.00, 12.00, 'Calendar Monthly', '2023', 32, 294, '2023-03-29', 'Jun', '1000'),
(16, 'Qualesce INDIA', 3, 'Qualesce-elec-00002', 0, '10', '', '10', 12.00, 15.00, 'Calendar Quarterly', '2023', 36, 107, '2023-03-30', 'q1', '1000'),
(17, 'TestParent', 4, 'TestClient-elec-00001', 0, '', '10', '1000', 10.00, 15.00, 'Calendar Quarterly', '2023', 41, 127, '2023-03-30', 'q1', '10000'),
(18, 'TestParent', 4, 'TestClient-elec-00001', 0, '', '20', '6000', 20.00, 30.00, 'Calendar Quarterly', '2023', 41, 130, '2023-03-30', 'q4', '30000'),
(19, 'TestParent', 4, 'TestClient-elec-00001', 0, '', '20', '24000', 15.00, 25.00, 'Calendar Yearly', '2024', 40, 27, '2023-03-30', '', '120000'),
(20, 'TestParent', 4, 'TestClient-elec-00001', 0, '', '20', '2000', 30.00, 45.00, 'Calendar Monthly', '2024', 42, 350, '2023-03-30', 'Jun', '10000'),
(21, 'TestParent', 4, 'TestClient-elec-00001', 0, '', '20', '6000', 45.00, 55.00, 'Calendar Quarterly', '2024', 41, 134, '2023-03-30', 'q4', '30000'),
(22, 'TestParent', 4, 'TestClient-elec-00002', 0, '400', '', '400', 45.00, 55.00, 'Calendar Quarterly', '2023', 44, 139, '2023-03-30', 'q1', '10000'),
(23, 'TestParent', 4, 'TestClient-elec-00002', 0, '', '20', '2000', 40.00, 50.00, 'Calendar Monthly', '2023', 45, 372, '2023-03-30', 'Jun', '10000'),
(24, 'TestParent', 4, 'TestClient-elec-00003', 5, '', '', '3720', 35.00, 55.00, 'Calendar Monthly', '2023', 48, 405, '2023-03-30', 'May', '100000'),
(25, 'TestParent', 4, 'TestClient-elec-00004', 0, '', '20', '6000', 45.00, 55.00, 'Calendar Quarterly', '2023', 49, 163, '2023-04-05', 'q2', '30000'),
(26, 'TestParent2', 5, 'TestClient2-elec-00001', 0, '', '10', '12000', 45.00, 55.00, 'Calendar Yearly', '2023', 50, 33, '2023-04-06', '', '120000');

-- --------------------------------------------------------

--
-- Table structure for table `nususerdata`
--

CREATE TABLE `nususerdata` (
  `id` int(11) NOT NULL,
  `role` varchar(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `emailId` varchar(100) NOT NULL,
  `accountstatus` varchar(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  `parentcompany` varchar(100) DEFAULT NULL,
  `bussinessunit` varchar(255) DEFAULT NULL,
  `active` enum('Active','Inactive') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nususerdata`
--

INSERT INTO `nususerdata` (`id`, `role`, `username`, `emailId`, `accountstatus`, `password`, `parentcompany`, `bussinessunit`, `active`) VALUES
(1, 'Admin', 'Admin', 'admin@nusconsulting.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$a085aUQyc3hKdHFSMllyQQ$bKQT8rWb/gTK6IOlavJ1BWa0mpMzrcQ9pQjfXAMBVP0', '', '', 'Active'),
(2, 'Admin', 'Richard', 'rsoultanian@nusconsulting.co.uk', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$M1BLcWdFUTV6Qm1MOW5iVA$WWMMFfr/o8dniZ6rkEHPvm6Vr94fgdTri2pa5R6E5MY', '', '', 'Active'),
(3, 'Admin', 'Miguel', 'mjimenez@nusconsulting.es', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$OGJnOWhMYmlnMUtoWHNkWA$RwMpkFnRWcQNdJTe7UcdL5MTzF4/NnaxAzp387RMlow', '', '', 'Active'),
(4, 'Admin', 'test', 'test@gmail.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$QzhXT0hpMUJLbnQuNU5LVA$gQzVi8RIElOaMn0lq6bT1MNHt353/aySBXqlP6oQlAs', '', '', 'Active'),
(5, 'Admin', 'Vinay', 'vinay.b@qualesce.com', 'Invited', '$argon2i$v=19$m=65536,t=4,p=1$ekFBV0Eyc0JJQ1JpLmlrRw$KSnDy+txSo00cufQ3ZMtPtYS72Ha1Y411xOGKqrCmOc', '', '', 'Active'),
(6, 'Admin', 'Vijay Kumar K T', 'vijayakumar.kt@qualesce.com', 'Invited', '$argon2i$v=19$m=65536,t=4,p=1$cXB1RU1HdFcxaVlta0hZLg$0sGpCT/2U6dPu81aX5YNfxs40ZbCIvXn/BRIBRmnjAE', '', '', 'Active'),
(7, 'Admin', 'vijay', 'vijaygowda973012@gmail.com', 'Invited', '$argon2i$v=19$m=65536,t=4,p=1$SVpVRFdSbW03N1k1NDNzSQ$+osT55Vcx+7ARw2lAWpBDxAdHEyXdjP4OHAy1kFExk8', '', '', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `nus_calendermonth`
--

CREATE TABLE `nus_calendermonth` (
  `monthId` int(11) NOT NULL,
  `month` varchar(20) NOT NULL,
  `clicks` int(11) NOT NULL,
  `TradeId` int(11) NOT NULL,
  `supplierId` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_calendermonth`
--

INSERT INTO `nus_calendermonth` (`monthId`, `month`, `clicks`, `TradeId`, `supplierId`, `year`) VALUES
(1, 'Mar', 4, 4, 5, 2023),
(2, 'Apr', 4, 4, 5, 2023),
(3, 'May', 4, 4, 5, 2023),
(4, 'Jun', 4, 4, 5, 2023),
(5, 'July', 4, 4, 5, 2023),
(6, 'Aug', 4, 4, 5, 2023),
(7, 'Sep', 4, 4, 5, 2023),
(8, 'Oct', 4, 4, 5, 2023),
(9, 'Nov', 4, 4, 5, 2023),
(10, 'Dec', 4, 4, 5, 2023),
(11, 'Jan', 4, 4, 5, 2024),
(12, 'Feb', 4, 4, 5, 2024),
(13, 'Mar', 4, 4, 5, 2024),
(14, 'Apr', 4, 4, 5, 2024),
(15, 'May', 4, 4, 5, 2024),
(16, 'Jun', 4, 4, 5, 2024),
(17, 'July', 4, 4, 5, 2024),
(18, 'Aug', 4, 4, 5, 2024),
(19, 'Sep', 4, 4, 5, 2024),
(20, 'Oct', 4, 4, 5, 2024),
(21, 'Nov', 4, 4, 5, 2024),
(22, 'Dec', 4, 4, 5, 2024),
(23, 'July', 5, 8, 7, 2023),
(24, 'Aug', 5, 8, 7, 2023),
(25, 'Sep', 5, 8, 7, 2023),
(26, 'Oct', 5, 8, 7, 2023),
(27, 'Nov', 5, 8, 7, 2023),
(28, 'Dec', 5, 8, 7, 2023),
(29, 'Jan', 5, 8, 7, 2024),
(30, 'Feb', 5, 8, 7, 2024),
(31, 'Mar', 5, 8, 7, 2024),
(32, 'Apr', 5, 8, 7, 2024),
(33, 'May', 5, 8, 7, 2024),
(34, 'Jun', 5, 8, 7, 2024),
(35, 'July', 5, 8, 7, 2024),
(36, 'Aug', 5, 8, 7, 2024),
(37, 'Sep', 5, 8, 7, 2024),
(38, 'Oct', 5, 8, 7, 2024),
(39, 'Nov', 5, 8, 7, 2024),
(40, 'Dec', 5, 8, 7, 2024),
(41, 'Jan', 5, 8, 7, 2025),
(42, 'Feb', 5, 8, 7, 2025),
(43, 'Mar', 5, 8, 7, 2025),
(44, 'Apr', 5, 8, 7, 2025),
(45, 'May', 5, 8, 7, 2025),
(46, 'Jun', 5, 8, 7, 2025),
(47, 'July', 5, 8, 7, 2025),
(48, 'Aug', 5, 8, 7, 2025),
(49, 'Sep', 5, 8, 7, 2025),
(50, 'Oct', 5, 8, 7, 2025),
(51, 'Nov', 5, 8, 7, 2025),
(52, 'Dec', 5, 8, 7, 2025),
(53, 'July', 6, 11, 8, 2023),
(54, 'Aug', 6, 11, 8, 2023),
(55, 'Sep', 6, 11, 8, 2023),
(56, 'Oct', 6, 11, 8, 2023),
(57, 'Nov', 6, 11, 8, 2023),
(58, 'Dec', 6, 11, 8, 2023),
(59, 'Jan', 6, 11, 8, 2024),
(60, 'Feb', 6, 11, 8, 2024),
(61, 'Mar', 6, 11, 8, 2024),
(62, 'Apr', 6, 11, 8, 2024),
(63, 'May', 6, 11, 8, 2024),
(64, 'Jun', 6, 11, 8, 2024),
(65, 'July', 6, 11, 8, 2024),
(66, 'Aug', 6, 11, 8, 2024),
(67, 'Sep', 6, 11, 8, 2024),
(68, 'Oct', 6, 11, 8, 2024),
(69, 'Nov', 6, 11, 8, 2024),
(70, 'Dec', 6, 11, 8, 2024),
(71, 'Jan', 6, 11, 8, 2025),
(72, 'Feb', 6, 11, 8, 2025),
(73, 'Mar', 6, 11, 8, 2025),
(74, 'Apr', 6, 11, 8, 2025),
(75, 'May', 6, 11, 8, 2025),
(76, 'Jun', 6, 11, 8, 2025),
(77, 'July', 6, 11, 8, 2025),
(78, 'Aug', 6, 11, 8, 2025),
(79, 'Sep', 6, 11, 8, 2025),
(80, 'Oct', 6, 11, 8, 2025),
(81, 'Nov', 6, 11, 8, 2025),
(82, 'Dec', 6, 11, 8, 2025),
(83, 'July', 6, 14, 9, 2023),
(84, 'Aug', 6, 14, 9, 2023),
(85, 'Sep', 6, 14, 9, 2023),
(86, 'Oct', 6, 14, 9, 2023),
(87, 'Nov', 6, 14, 9, 2023),
(88, 'Dec', 6, 14, 9, 2023),
(89, 'Jan', 6, 14, 9, 2024),
(90, 'Feb', 6, 14, 9, 2024),
(91, 'Mar', 6, 14, 9, 2024),
(92, 'Apr', 6, 14, 9, 2024),
(93, 'May', 6, 14, 9, 2024),
(94, 'Jun', 6, 14, 9, 2024),
(95, 'July', 6, 14, 9, 2024),
(96, 'Aug', 6, 14, 9, 2024),
(97, 'Sep', 6, 14, 9, 2024),
(98, 'Oct', 6, 14, 9, 2024),
(99, 'Nov', 6, 14, 9, 2024),
(100, 'Dec', 6, 14, 9, 2024),
(101, 'Jan', 6, 14, 9, 2025),
(102, 'Feb', 6, 14, 9, 2025),
(103, 'Mar', 6, 14, 9, 2025),
(104, 'Apr', 6, 14, 9, 2025),
(105, 'May', 6, 14, 9, 2025),
(106, 'Jun', 6, 14, 9, 2025),
(107, 'July', 6, 14, 9, 2025),
(108, 'Aug', 6, 14, 9, 2025),
(109, 'Sep', 6, 14, 9, 2025),
(110, 'Oct', 6, 14, 9, 2025),
(111, 'Nov', 6, 14, 9, 2025),
(112, 'Dec', 6, 14, 9, 2025),
(113, 'July', 6, 17, 10, 2023),
(114, 'Aug', 6, 17, 10, 2023),
(115, 'Sep', 6, 17, 10, 2023),
(116, 'Oct', 6, 17, 10, 2023),
(117, 'Nov', 6, 17, 10, 2023),
(118, 'Dec', 6, 17, 10, 2023),
(119, 'Jan', 6, 17, 10, 2024),
(120, 'Feb', 6, 17, 10, 2024),
(121, 'Mar', 6, 17, 10, 2024),
(122, 'Apr', 6, 17, 10, 2024),
(123, 'May', 6, 17, 10, 2024),
(124, 'Jun', 6, 17, 10, 2024),
(125, 'July', 6, 17, 10, 2024),
(126, 'Aug', 6, 17, 10, 2024),
(127, 'Sep', 6, 17, 10, 2024),
(128, 'Oct', 6, 17, 10, 2024),
(129, 'Nov', 6, 17, 10, 2024),
(130, 'Dec', 6, 17, 10, 2024),
(131, 'Jan', 6, 17, 10, 2025),
(132, 'Feb', 6, 17, 10, 2025),
(133, 'Mar', 6, 17, 10, 2025),
(134, 'Apr', 6, 17, 10, 2025),
(135, 'May', 6, 17, 10, 2025),
(136, 'Jun', 6, 17, 10, 2025),
(137, 'July', 6, 17, 10, 2025),
(138, 'Aug', 6, 17, 10, 2025),
(139, 'Sep', 6, 17, 10, 2025),
(140, 'Oct', 6, 17, 10, 2025),
(141, 'Nov', 6, 17, 10, 2025),
(142, 'Dec', 6, 17, 10, 2025),
(143, 'July', 5, 20, 11, 2023),
(144, 'Aug', 5, 20, 11, 2023),
(145, 'Sep', 5, 20, 11, 2023),
(146, 'Oct', 5, 20, 11, 2023),
(147, 'Nov', 5, 20, 11, 2023),
(148, 'Dec', 5, 20, 11, 2023),
(149, 'Jan', 5, 20, 11, 2024),
(150, 'Feb', 5, 20, 11, 2024),
(151, 'Mar', 5, 20, 11, 2024),
(152, 'Apr', 5, 20, 11, 2024),
(153, 'May', 5, 20, 11, 2024),
(154, 'Jun', 5, 20, 11, 2024),
(155, 'July', 5, 20, 11, 2024),
(156, 'Aug', 5, 20, 11, 2024),
(157, 'Sep', 5, 20, 11, 2024),
(158, 'Oct', 5, 20, 11, 2024),
(159, 'Nov', 5, 20, 11, 2024),
(160, 'Dec', 5, 20, 11, 2024),
(161, 'Jan', 5, 20, 11, 2025),
(162, 'Feb', 5, 20, 11, 2025),
(163, 'Mar', 5, 20, 11, 2025),
(164, 'Apr', 5, 20, 11, 2025),
(165, 'May', 5, 20, 11, 2025),
(166, 'Jun', 5, 20, 11, 2025),
(167, 'July', 5, 20, 11, 2025),
(168, 'Aug', 5, 20, 11, 2025),
(169, 'Sep', 5, 20, 11, 2025),
(170, 'Oct', 5, 20, 11, 2025),
(171, 'Nov', 5, 20, 11, 2025),
(172, 'Dec', 5, 20, 11, 2025),
(173, 'Jan', 2, 23, 15, 2023),
(174, 'Feb', 2, 23, 15, 2023),
(175, 'Mar', 2, 23, 15, 2023),
(176, 'Apr', 2, 23, 15, 2023),
(177, 'May', 2, 23, 15, 2023),
(178, 'Jun', 2, 23, 15, 2023),
(179, 'July', 2, 23, 15, 2023),
(180, 'Aug', 2, 23, 15, 2023),
(181, 'Sep', 2, 23, 15, 2023),
(182, 'Oct', 2, 23, 15, 2023),
(183, 'Nov', 2, 23, 15, 2023),
(184, 'Dec', 2, 23, 15, 2023),
(185, 'Jan', 2, 23, 15, 2024),
(186, 'Feb', 2, 23, 15, 2024),
(187, 'Mar', 2, 23, 15, 2024),
(188, 'Apr', 2, 23, 15, 2024),
(189, 'May', 2, 23, 15, 2024),
(190, 'Jun', 2, 23, 15, 2024),
(191, 'July', 2, 23, 15, 2024),
(192, 'Aug', 2, 23, 15, 2024),
(193, 'Sep', 2, 23, 15, 2024),
(194, 'Oct', 2, 23, 15, 2024),
(195, 'Nov', 2, 23, 15, 2024),
(196, 'Dec', 2, 23, 15, 2024),
(197, 'Jan', 2, 23, 15, 2025),
(198, 'Feb', 2, 23, 15, 2025),
(199, 'Mar', 2, 23, 15, 2025),
(200, 'Apr', 2, 23, 15, 2025),
(201, 'May', 2, 23, 15, 2025),
(202, 'Jun', 2, 23, 15, 2025),
(203, 'July', 2, 23, 15, 2025),
(204, 'Aug', 2, 23, 15, 2025),
(205, 'Sep', 2, 23, 15, 2025),
(206, 'Oct', 2, 23, 15, 2025),
(207, 'Nov', 2, 23, 15, 2025),
(208, 'Dec', 2, 23, 15, 2025),
(255, 'Mar', 1, 29, 16, 2023),
(256, 'Apr', 1, 29, 16, 2023),
(257, 'May', 1, 29, 16, 2023),
(258, 'Jun', 1, 29, 16, 2023),
(259, 'July', 1, 29, 16, 2023),
(260, 'Aug', 1, 29, 16, 2023),
(261, 'Sep', 1, 29, 16, 2023),
(262, 'Oct', 1, 29, 16, 2023),
(263, 'Nov', 1, 29, 16, 2023),
(264, 'Dec', 1, 29, 16, 2023),
(265, 'Jan', 1, 29, 16, 2024),
(266, 'Feb', 1, 29, 16, 2024),
(267, 'Mar', 1, 29, 16, 2024),
(268, 'Apr', 1, 29, 16, 2024),
(269, 'May', 1, 29, 16, 2024),
(270, 'Jun', 1, 29, 16, 2024),
(271, 'July', 1, 29, 16, 2024),
(272, 'Aug', 1, 29, 16, 2024),
(273, 'Sep', 1, 29, 16, 2024),
(274, 'Oct', 1, 29, 16, 2024),
(275, 'Nov', 1, 29, 16, 2024),
(276, 'Dec', 1, 29, 16, 2024),
(277, 'Jan', 1, 29, 16, 2025),
(278, 'Feb', 1, 29, 16, 2025),
(279, 'Mar', 1, 29, 16, 2025),
(280, 'Apr', 1, 29, 16, 2025),
(281, 'May', 1, 29, 16, 2025),
(282, 'Jun', 1, 29, 16, 2025),
(283, 'July', 1, 29, 16, 2025),
(284, 'Aug', 1, 29, 16, 2025),
(285, 'Sep', 1, 29, 16, 2025),
(286, 'Oct', 1, 29, 16, 2025),
(287, 'Nov', 1, 29, 16, 2025),
(288, 'Dec', 1, 29, 16, 2025),
(289, 'Jan', 2, 32, 17, 2023),
(290, 'Feb', 2, 32, 17, 2023),
(291, 'Mar', 2, 32, 17, 2023),
(292, 'Apr', 2, 32, 17, 2023),
(293, 'May', 2, 32, 17, 2023),
(294, 'Jun', 1, 32, 17, 2023),
(295, 'July', 2, 32, 17, 2023),
(296, 'Aug', 2, 32, 17, 2023),
(297, 'Sep', 2, 32, 17, 2023),
(298, 'Oct', 2, 32, 17, 2023),
(299, 'Nov', 2, 32, 17, 2023),
(300, 'Dec', 2, 32, 17, 2023),
(301, 'Mar', 4, 39, 21, 2023),
(302, 'Apr', 4, 39, 21, 2023),
(303, 'May', 4, 39, 21, 2023),
(304, 'Jun', 4, 39, 21, 2023),
(305, 'July', 4, 39, 21, 2023),
(306, 'Aug', 4, 39, 21, 2023),
(307, 'Sep', 4, 39, 21, 2023),
(308, 'Oct', 4, 39, 21, 2023),
(309, 'Nov', 4, 39, 21, 2023),
(310, 'Dec', 4, 39, 21, 2023),
(311, 'Jan', 4, 39, 21, 2024),
(312, 'Feb', 4, 39, 21, 2024),
(313, 'Mar', 4, 39, 21, 2024),
(314, 'Apr', 4, 39, 21, 2024),
(315, 'May', 4, 39, 21, 2024),
(316, 'Jun', 4, 39, 21, 2024),
(317, 'July', 4, 39, 21, 2024),
(318, 'Aug', 4, 39, 21, 2024),
(319, 'Sep', 4, 39, 21, 2024),
(320, 'Oct', 4, 39, 21, 2024),
(321, 'Nov', 4, 39, 21, 2024),
(322, 'Dec', 4, 39, 21, 2024),
(323, 'Jan', 4, 39, 21, 2025),
(324, 'Feb', 4, 39, 21, 2025),
(325, 'Mar', 4, 39, 21, 2025),
(326, 'Apr', 4, 39, 21, 2025),
(327, 'May', 4, 39, 21, 2025),
(328, 'Jun', 4, 39, 21, 2025),
(329, 'July', 4, 39, 21, 2025),
(330, 'Aug', 4, 39, 21, 2025),
(331, 'Sep', 4, 39, 21, 2025),
(332, 'Oct', 4, 39, 21, 2025),
(333, 'Nov', 4, 39, 21, 2025),
(334, 'Dec', 4, 39, 21, 2025),
(335, 'Mar', 4, 42, 22, 2023),
(336, 'Apr', 4, 42, 22, 2023),
(337, 'May', 4, 42, 22, 2023),
(338, 'Jun', 4, 42, 22, 2023),
(339, 'July', 4, 42, 22, 2023),
(340, 'Aug', 4, 42, 22, 2023),
(341, 'Sep', 4, 42, 22, 2023),
(342, 'Oct', 4, 42, 22, 2023),
(343, 'Nov', 4, 42, 22, 2023),
(344, 'Dec', 4, 42, 22, 2023),
(345, 'Jan', 4, 42, 22, 2024),
(346, 'Feb', 4, 42, 22, 2024),
(347, 'Mar', 4, 42, 22, 2024),
(348, 'Apr', 4, 42, 22, 2024),
(349, 'May', 4, 42, 22, 2024),
(350, 'Jun', 3, 42, 22, 2024),
(351, 'July', 4, 42, 22, 2024),
(352, 'Aug', 4, 42, 22, 2024),
(353, 'Sep', 4, 42, 22, 2024),
(354, 'Oct', 4, 42, 22, 2024),
(355, 'Nov', 4, 42, 22, 2024),
(356, 'Dec', 4, 42, 22, 2024),
(357, 'Jan', 4, 42, 22, 2025),
(358, 'Feb', 4, 42, 22, 2025),
(359, 'Mar', 4, 42, 22, 2025),
(360, 'Apr', 4, 42, 22, 2025),
(361, 'May', 4, 42, 22, 2025),
(362, 'Jun', 4, 42, 22, 2025),
(363, 'July', 4, 42, 22, 2025),
(364, 'Aug', 4, 42, 22, 2025),
(365, 'Sep', 4, 42, 22, 2025),
(366, 'Oct', 4, 42, 22, 2025),
(367, 'Nov', 4, 42, 22, 2025),
(368, 'Dec', 4, 42, 22, 2025),
(369, 'Mar', 5, 45, 23, 2023),
(370, 'Apr', 5, 45, 23, 2023),
(371, 'May', 5, 45, 23, 2023),
(372, 'Jun', 4, 45, 23, 2023),
(373, 'July', 5, 45, 23, 2023),
(374, 'Aug', 5, 45, 23, 2023),
(375, 'Sep', 5, 45, 23, 2023),
(376, 'Oct', 5, 45, 23, 2023),
(377, 'Nov', 5, 45, 23, 2023),
(378, 'Dec', 5, 45, 23, 2023),
(379, 'Jan', 5, 45, 23, 2024),
(380, 'Feb', 5, 45, 23, 2024),
(381, 'Mar', 5, 45, 23, 2024),
(382, 'Apr', 5, 45, 23, 2024),
(383, 'May', 5, 45, 23, 2024),
(384, 'Jun', 5, 45, 23, 2024),
(385, 'July', 5, 45, 23, 2024),
(386, 'Aug', 5, 45, 23, 2024),
(387, 'Sep', 5, 45, 23, 2024),
(388, 'Oct', 5, 45, 23, 2024),
(389, 'Nov', 5, 45, 23, 2024),
(390, 'Dec', 5, 45, 23, 2024),
(391, 'Jan', 5, 45, 23, 2025),
(392, 'Feb', 5, 45, 23, 2025),
(393, 'Mar', 5, 45, 23, 2025),
(394, 'Apr', 5, 45, 23, 2025),
(395, 'May', 5, 45, 23, 2025),
(396, 'Jun', 5, 45, 23, 2025),
(397, 'July', 5, 45, 23, 2025),
(398, 'Aug', 5, 45, 23, 2025),
(399, 'Sep', 5, 45, 23, 2025),
(400, 'Oct', 5, 45, 23, 2025),
(401, 'Nov', 5, 45, 23, 2025),
(402, 'Dec', 5, 45, 23, 2025),
(403, 'Mar', 5, 48, 24, 2023),
(404, 'Apr', 5, 48, 24, 2023),
(405, 'May', 4, 48, 24, 2023),
(406, 'Jun', 5, 48, 24, 2023),
(407, 'July', 5, 48, 24, 2023),
(408, 'Aug', 5, 48, 24, 2023),
(409, 'Sep', 5, 48, 24, 2023),
(410, 'Oct', 5, 48, 24, 2023),
(411, 'Nov', 5, 48, 24, 2023),
(412, 'Dec', 5, 48, 24, 2023),
(413, 'Jan', 5, 48, 24, 2024),
(414, 'Feb', 5, 48, 24, 2024),
(415, 'Mar', 5, 48, 24, 2024),
(416, 'Apr', 5, 48, 24, 2024),
(417, 'May', 5, 48, 24, 2024),
(418, 'Jun', 5, 48, 24, 2024),
(419, 'July', 5, 48, 24, 2024),
(420, 'Aug', 5, 48, 24, 2024),
(421, 'Sep', 5, 48, 24, 2024),
(422, 'Oct', 5, 48, 24, 2024),
(423, 'Nov', 5, 48, 24, 2024),
(424, 'Dec', 5, 48, 24, 2024),
(425, 'Jan', 5, 48, 24, 2025),
(426, 'Feb', 5, 48, 24, 2025),
(427, 'Mar', 5, 48, 24, 2025),
(428, 'Apr', 5, 48, 24, 2025),
(429, 'May', 5, 48, 24, 2025),
(430, 'Jun', 5, 48, 24, 2025),
(431, 'July', 5, 48, 24, 2025),
(432, 'Aug', 5, 48, 24, 2025),
(433, 'Sep', 5, 48, 24, 2025),
(434, 'Oct', 5, 48, 24, 2025),
(435, 'Nov', 5, 48, 24, 2025),
(436, 'Dec', 5, 48, 24, 2025);

-- --------------------------------------------------------

--
-- Table structure for table `nus_calenderquarter`
--

CREATE TABLE `nus_calenderquarter` (
  `querterid` int(11) NOT NULL,
  `quarters` varchar(50) NOT NULL,
  `clicks` int(11) NOT NULL,
  `tradeid` int(11) NOT NULL,
  `supplierid` int(11) NOT NULL,
  `yearoftrade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_calenderquarter`
--

INSERT INTO `nus_calenderquarter` (`querterid`, `quarters`, `clicks`, `tradeid`, `supplierid`, `yearoftrade`) VALUES
(1, 'q1', 4, 3, 5, 2023),
(2, 'q2', 4, 3, 5, 2023),
(3, 'q3', 4, 3, 5, 2023),
(4, 'q4', 4, 3, 5, 2023),
(5, 'q1', 4, 3, 5, 2024),
(6, 'q2', 4, 3, 5, 2024),
(7, 'q3', 4, 3, 5, 2024),
(8, 'q4', 4, 3, 5, 2024),
(9, 'q3', 4, 7, 7, 2023),
(10, 'q4', 5, 7, 7, 2023),
(11, 'q1', 5, 7, 7, 2024),
(12, 'q2', 5, 7, 7, 2024),
(13, 'q3', 5, 7, 7, 2024),
(14, 'q4', 5, 7, 7, 2024),
(15, 'q1', 5, 7, 7, 2025),
(16, 'q2', 5, 7, 7, 2025),
(17, 'q3', 5, 7, 7, 2025),
(18, 'q4', 5, 7, 7, 2025),
(19, 'q3', 5, 10, 8, 2023),
(20, 'q4', 5, 10, 8, 2023),
(21, 'q1', 5, 10, 8, 2024),
(22, 'q2', 5, 10, 8, 2024),
(23, 'q3', 5, 10, 8, 2024),
(24, 'q4', 5, 10, 8, 2024),
(25, 'q1', 5, 10, 8, 2025),
(26, 'q2', 5, 10, 8, 2025),
(27, 'q3', 5, 10, 8, 2025),
(28, 'q4', 5, 10, 8, 2025),
(29, 'q3', 5, 13, 9, 2023),
(30, 'q4', 5, 13, 9, 2023),
(31, 'q1', 5, 13, 9, 2024),
(32, 'q2', 5, 13, 9, 2024),
(33, 'q3', 5, 13, 9, 2024),
(34, 'q4', 5, 13, 9, 2024),
(35, 'q1', 5, 13, 9, 2025),
(36, 'q2', 5, 13, 9, 2025),
(37, 'q3', 5, 13, 9, 2025),
(38, 'q4', 5, 13, 9, 2025),
(39, 'q3', 5, 16, 10, 2023),
(40, 'q4', 5, 16, 10, 2023),
(41, 'q1', 5, 16, 10, 2024),
(42, 'q2', 5, 16, 10, 2024),
(43, 'q3', 5, 16, 10, 2024),
(44, 'q4', 5, 16, 10, 2024),
(45, 'q1', 5, 16, 10, 2025),
(46, 'q2', 5, 16, 10, 2025),
(47, 'q3', 5, 16, 10, 2025),
(48, 'q4', 5, 16, 10, 2025),
(49, 'q3', 5, 19, 11, 2023),
(50, 'q4', 5, 19, 11, 2023),
(51, 'q1', 5, 19, 11, 2024),
(52, 'q2', 5, 19, 11, 2024),
(53, 'q3', 5, 19, 11, 2024),
(54, 'q4', 5, 19, 11, 2024),
(55, 'q1', 5, 19, 11, 2025),
(56, 'q2', 5, 19, 11, 2025),
(57, 'q3', 5, 19, 11, 2025),
(58, 'q4', 5, 19, 11, 2025),
(59, 'q1', 2, 22, 15, 2023),
(60, 'q2', 1, 22, 15, 2023),
(61, 'q3', 2, 22, 15, 2023),
(62, 'q4', 1, 22, 15, 2023),
(63, 'q1', 2, 22, 15, 2024),
(64, 'q2', 2, 22, 15, 2024),
(65, 'q3', 2, 22, 15, 2024),
(66, 'q4', 2, 22, 15, 2024),
(67, 'q1', 2, 22, 15, 2025),
(68, 'q2', 2, 22, 15, 2025),
(69, 'q3', 2, 22, 15, 2025),
(70, 'q4', 2, 22, 15, 2025),
(87, 'q1', 1, 28, 16, 2023),
(88, 'q2', 1, 28, 16, 2023),
(89, 'q3', 1, 28, 16, 2023),
(90, 'q4', 1, 28, 16, 2023),
(91, 'q1', 1, 28, 16, 2024),
(92, 'q2', 1, 28, 16, 2024),
(93, 'q3', 1, 28, 16, 2024),
(94, 'q4', 1, 28, 16, 2024),
(95, 'q1', 1, 28, 16, 2025),
(96, 'q2', 1, 28, 16, 2025),
(97, 'q3', 1, 28, 16, 2025),
(98, 'q4', 1, 28, 16, 2025),
(99, 'q1', 2, 31, 17, 2023),
(100, 'q2', 2, 31, 17, 2023),
(101, 'q3', 2, 31, 17, 2023),
(102, 'q4', 1, 31, 17, 2023),
(103, 'q1', 5, 34, 18, 2023),
(104, 'q2', 5, 34, 18, 2023),
(105, 'q3', 5, 34, 18, 2023),
(106, 'q4', 5, 34, 18, 2023),
(107, 'q1', 4, 36, 19, 2023),
(108, 'q2', 5, 36, 19, 2023),
(109, 'q3', 5, 36, 19, 2023),
(110, 'q4', 5, 36, 19, 2023),
(111, 'q1', 5, 36, 19, 2024),
(112, 'q2', 5, 36, 19, 2024),
(113, 'q3', 5, 36, 19, 2024),
(114, 'q4', 5, 36, 19, 2024),
(115, 'q1', 4, 38, 21, 2023),
(116, 'q2', 4, 38, 21, 2023),
(117, 'q3', 4, 38, 21, 2023),
(118, 'q4', 4, 38, 21, 2023),
(119, 'q1', 4, 38, 21, 2024),
(120, 'q2', 4, 38, 21, 2024),
(121, 'q3', 4, 38, 21, 2024),
(122, 'q4', 4, 38, 21, 2024),
(123, 'q1', 4, 38, 21, 2025),
(124, 'q2', 4, 38, 21, 2025),
(125, 'q3', 4, 38, 21, 2025),
(126, 'q4', 4, 38, 21, 2025),
(127, 'q1', 3, 41, 22, 2023),
(128, 'q2', 4, 41, 22, 2023),
(129, 'q3', 4, 41, 22, 2023),
(130, 'q4', 3, 41, 22, 2023),
(131, 'q1', 4, 41, 22, 2024),
(132, 'q2', 4, 41, 22, 2024),
(133, 'q3', 4, 41, 22, 2024),
(134, 'q4', 3, 41, 22, 2024),
(135, 'q1', 4, 41, 22, 2025),
(136, 'q2', 4, 41, 22, 2025),
(137, 'q3', 4, 41, 22, 2025),
(138, 'q4', 4, 41, 22, 2025),
(139, 'q1', 4, 44, 23, 2023),
(140, 'q2', 5, 44, 23, 2023),
(141, 'q3', 5, 44, 23, 2023),
(142, 'q4', 5, 44, 23, 2023),
(143, 'q1', 5, 44, 23, 2024),
(144, 'q2', 5, 44, 23, 2024),
(145, 'q3', 5, 44, 23, 2024),
(146, 'q4', 5, 44, 23, 2024),
(147, 'q1', 5, 44, 23, 2025),
(148, 'q2', 5, 44, 23, 2025),
(149, 'q3', 5, 44, 23, 2025),
(150, 'q4', 5, 44, 23, 2025),
(151, 'q1', 5, 47, 24, 2023),
(152, 'q2', 5, 47, 24, 2023),
(153, 'q3', 5, 47, 24, 2023),
(154, 'q4', 5, 47, 24, 2023),
(155, 'q1', 5, 47, 24, 2024),
(156, 'q2', 5, 47, 24, 2024),
(157, 'q3', 5, 47, 24, 2024),
(158, 'q4', 5, 47, 24, 2024),
(159, 'q1', 5, 47, 24, 2025),
(160, 'q2', 5, 47, 24, 2025),
(161, 'q3', 5, 47, 24, 2025),
(162, 'q4', 5, 47, 24, 2025),
(163, 'q2', 3, 49, 25, 2023),
(164, 'q3', 4, 49, 25, 2023),
(165, 'q4', 4, 49, 25, 2023),
(166, 'q1', 4, 51, 26, 2023),
(167, 'q2', 4, 51, 26, 2023),
(168, 'q3', 4, 51, 26, 2023),
(169, 'q4', 4, 51, 26, 2023);

-- --------------------------------------------------------

--
-- Table structure for table `nus_calenderyear`
--

CREATE TABLE `nus_calenderyear` (
  `calenderId` int(11) NOT NULL,
  `calenderyear` int(11) NOT NULL,
  `clicks` int(11) NOT NULL,
  `tradeId` int(11) NOT NULL,
  `supplierid` int(11) NOT NULL,
  `timeperiod` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_calenderyear`
--

INSERT INTO `nus_calenderyear` (`calenderId`, `calenderyear`, `clicks`, `tradeId`, `supplierid`, `timeperiod`) VALUES
(1, 2023, 0, 1, 1, '2023-1-01,2023-12-01'),
(2, 2024, 0, 2, 5, '2024-1-01,2024-12-01'),
(3, 2024, 3, 5, 6, '2024-1-01,2024-12-01'),
(4, 2025, 4, 5, 6, '2025-1-01,2025-12-01'),
(5, 2024, 5, 6, 7, '2024-1-01,2024-12-01'),
(6, 2025, 5, 6, 7, '2025-1-01,2025-12-01'),
(7, 2024, 4, 9, 8, '2024-1-01,2024-12-01'),
(8, 2025, 4, 9, 8, '2025-1-01,2025-12-01'),
(9, 2024, 4, 12, 9, '2024-1-01,2024-12-01'),
(10, 2025, 4, 12, 9, '2025-1-01,2025-12-01'),
(11, 2024, 2, 15, 10, '2024-1-01,2024-12-01'),
(12, 2025, 4, 15, 10, '2025-1-01,2025-12-01'),
(13, 2024, 3, 18, 11, '2024-1-01,2024-12-01'),
(14, 2025, 4, 18, 11, '2025-1-01,2025-12-01'),
(15, 2023, 1, 21, 15, '2023-1-01,2023-12-01'),
(16, 2024, 2, 21, 15, '2024-1-01,2024-12-01'),
(17, 2025, 1, 21, 15, '2025-1-01,2025-12-01'),
(21, 2024, 1, 27, 16, '2023-3-01,2024-2-01'),
(22, 2025, 1, 27, 16, '2024-3-01,2025-2-01'),
(23, 2023, 0, 30, 17, '2023-1-01,2023-12-01'),
(24, 2024, 4, 35, 19, '2024-1-01,2024-12-01'),
(25, 2024, 4, 37, 21, '2024-1-01,2024-12-01'),
(26, 2025, 4, 37, 21, '2025-1-01,2025-12-01'),
(27, 2024, 3, 40, 22, '2024-1-01,2024-12-01'),
(28, 2025, 4, 40, 22, '2025-1-01,2025-12-01'),
(29, 2024, 4, 43, 23, '2024-1-01,2024-12-01'),
(30, 2025, 4, 43, 23, '2025-1-01,2025-12-01'),
(31, 2024, 4, 46, 24, '2024-1-01,2024-12-01'),
(32, 2025, 4, 46, 24, '2025-1-01,2025-12-01'),
(33, 2023, 3, 50, 26, '2023-1-01,2023-12-01');

-- --------------------------------------------------------

--
-- Table structure for table `nus_countries`
--

CREATE TABLE `nus_countries` (
  `countryId` int(11) NOT NULL,
  `countryName` varchar(255) NOT NULL,
  `addedOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_countries`
--

INSERT INTO `nus_countries` (`countryId`, `countryName`, `addedOn`) VALUES
(1, 'India', '2022-05-19 13:20:42'),
(2, 'Sri Lanka', '2022-05-19 13:20:42'),
(3, 'United Kingdom', '2022-07-20 15:40:12');

-- --------------------------------------------------------

--
-- Table structure for table `nus_currencies`
--

CREATE TABLE `nus_currencies` (
  `id` tinyint(4) NOT NULL,
  `currencies` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_currencies`
--

INSERT INTO `nus_currencies` (`id`, `currencies`) VALUES
(3, 'AUD'),
(4, 'CAD'),
(5, 'CHF'),
(6, 'CZK'),
(2, 'EUR'),
(7, 'GBP'),
(8, 'HUF'),
(9, 'PLN'),
(10, 'SEK'),
(11, 'SGD'),
(1, 'USD');

-- --------------------------------------------------------

--
-- Table structure for table `nus_electricity_index`
--

CREATE TABLE `nus_electricity_index` (
  `id` tinyint(4) NOT NULL,
  `country` varchar(30) NOT NULL,
  `indexlist` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_electricity_index`
--

INSERT INTO `nus_electricity_index` (`id`, `country`, `indexlist`) VALUES
(1, 'Australia', 'ASX'),
(2, 'Austria', 'EEX/Austria'),
(3, 'Czech', 'EEX-PXE/Czechia'),
(4, 'Denmark', 'Nasdaq OMX/Denmark'),
(5, 'Finland', 'Nasdaq OMX/Finland'),
(6, 'France', 'EEX/France'),
(7, 'Germany', 'EEX/Deutschland'),
(8, 'Hungary', 'EEX-PXE/Hungary'),
(9, 'Hungary', 'PXE'),
(10, 'Italy', 'EEX/Italy'),
(11, 'Netherlands - Belgium\n', 'Ice Endex'),
(12, 'Norway', 'Nasdaq OMX/Norway'),
(13, 'Romania', 'OPCOM'),
(14, 'Slovakia', 'EEX-PXE/Slovakia'),
(15, 'Slovenia', 'EEX-PXE/Slovenia'),
(16, 'Spain - Portugal\n', 'OMIP'),
(17, 'Sweden ', 'Nasdaq OMX/Sweden'),
(18, 'Switzerland', 'EEX/Switzerland'),
(19, 'USA', 'CAISO NP-15 or SP-15'),
(20, 'USA', 'ERCOT North or Houston'),
(21, 'USA', 'Illinois Hub (MISO)'),
(22, 'USA', 'NEPOOL Internal Hub'),
(23, 'USA', 'NYISO Zone J (NYC area)'),
(24, 'USA', 'PJM Western Hub'),
(25, 'UK', 'OTC - NBP - UK'),
(26, 'UK', 'Futures - ICE - UK'),
(27, 'UK', 'N2EX Day-Ahead - UK');

-- --------------------------------------------------------

--
-- Table structure for table `nus_naturalgas_index`
--

CREATE TABLE `nus_naturalgas_index` (
  `id` tinyint(4) NOT NULL,
  `countries` varchar(30) NOT NULL,
  `indexlist` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_naturalgas_index`
--

INSERT INTO `nus_naturalgas_index` (`id`, `countries`, `indexlist`) VALUES
(1, 'Hungary', 'CEEGEX'),
(2, 'Austria', 'CEGH VTP'),
(3, 'Czech', 'CZ VTP'),
(4, 'Denmark', 'ETF/Denmark'),
(5, 'Norway', 'ETF/Norway'),
(6, 'Sweden ', 'ETF/Sweden'),
(7, 'UK', 'Futures - ICE - UK'),
(8, 'UK', 'Heren Day-Ahead - UK'),
(9, 'USA - Mexico', 'HSC [Houston Ship Channel]'),
(10, 'Spain - Portugal', 'MIBGAS'),
(11, 'USA', 'NYMEX'),
(12, 'Romania', 'OPCOM'),
(13, 'UK', 'OTC - NBP - UK'),
(14, 'France', 'PEG'),
(15, 'Austria', 'PEGAS/CEGH VTP'),
(16, 'Italy', 'PSV'),
(17, 'Germany - Switzerland', 'THE/PEGAS'),
(18, 'Netherlands', 'TTF');

-- --------------------------------------------------------

--
-- Table structure for table `nus_pricing_mechanisam`
--

CREATE TABLE `nus_pricing_mechanisam` (
  `priMechId` int(11) NOT NULL,
  `pricingMechName` varchar(128) NOT NULL,
  `priceMechDesc` varchar(255) NOT NULL,
  `addedOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_pricing_mechanisam`
--

INSERT INTO `nus_pricing_mechanisam` (`priMechId`, `pricingMechName`, `priceMechDesc`, `addedOn`) VALUES
(1, 'Day Ahead', 'Spot Daily Market', '2022-05-23 13:07:28'),
(2, 'Day Ahead', 'Spot Average for month', '2022-05-23 13:08:14'),
(3, 'Month Ahead', 'Last Value', '2022-05-23 13:08:14'),
(4, 'Month Ahead', 'Average Value', '2022-05-23 13:09:07'),
(5, 'Quarter Ahead', 'Last Value', '2022-05-23 13:09:07'),
(6, 'Quarter Ahead', 'Average Value', '2022-05-23 13:09:46'),
(7, 'Calendar Ahead', 'Last Value', '2022-05-23 13:09:46');

-- --------------------------------------------------------

--
-- Table structure for table `nus_season`
--

CREATE TABLE `nus_season` (
  `seasonId` int(11) NOT NULL,
  `tradeId` int(11) NOT NULL,
  `yeartrade` int(11) NOT NULL,
  `supplierId` int(11) NOT NULL,
  `season` varchar(30) NOT NULL,
  `clicks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nus_supply_contract`
--

CREATE TABLE `nus_supply_contract` (
  `supplierId` int(11) NOT NULL,
  `parentId` varchar(100) DEFAULT NULL,
  `clientId` int(11) DEFAULT NULL,
  `contract_id` varchar(128) DEFAULT NULL,
  `countryName` varchar(64) DEFAULT NULL,
  `commodityName` varchar(64) DEFAULT NULL,
  `commodityUnits` varchar(32) DEFAULT NULL,
  `supplyName` varchar(255) DEFAULT NULL,
  `contractType` varchar(32) DEFAULT NULL,
  `contractIndexId` varchar(64) DEFAULT NULL,
  `contractTermfromDate` date DEFAULT NULL,
  `contractTermtoDate` date DEFAULT NULL,
  `commodityPrice` float(10,2) DEFAULT 0.00,
  `totalAnualConsumption` varchar(30) DEFAULT NULL,
  `totlconsumption` varchar(50) DEFAULT NULL,
  `allmonts` text DEFAULT NULL,
  `contractpricetype` varchar(30) DEFAULT NULL,
  `indexStructureType` varchar(64) DEFAULT NULL,
  `consumMinsize` varchar(64) DEFAULT NULL,
  `clickTrancheminsize` int(11) DEFAULT NULL,
  `openPrizemechanism` varchar(255) DEFAULT NULL,
  `contractstatus` varchar(16) NOT NULL DEFAULT 'A',
  `consumptionmonth` text DEFAULT NULL,
  `hedgeconsumption` text DEFAULT NULL,
  `openconsumption` text DEFAULT NULL,
  `basegenconsumption` text DEFAULT NULL,
  `effectcon` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_supply_contract`
--

INSERT INTO `nus_supply_contract` (`supplierId`, `parentId`, `clientId`, `contract_id`, `countryName`, `commodityName`, `commodityUnits`, `supplyName`, `contractType`, `contractIndexId`, `contractTermfromDate`, `contractTermtoDate`, `commodityPrice`, `totalAnualConsumption`, `totlconsumption`, `allmonts`, `contractpricetype`, `indexStructureType`, `consumMinsize`, `clickTrancheminsize`, `openPrizemechanism`, `contractstatus`, `consumptionmonth`, `hedgeconsumption`, `openconsumption`, `basegenconsumption`, `effectcon`) VALUES
(1, 'Qualesce', 1, 'Qualesce-elec-00001', 'India', 'electricity', '', 'ELecc', 'indexed', 'ASX', '2023-01-01', '2023-12-31', 0.00, '120,000', '120000', '2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Day Ahead,Spot Average for month', 'A', 'Jan-2023-10000|Feb-2023-10000|Mar-2023-10000|Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000', 'Jan-2023-7200|Feb-2023-7200|Mar-2023-7200|Apr-2023-7200|May-2023-7200|Jun-2023-7200|July-2023-7200|Aug-2023-7200|Sep-2023-7200|Oct-2023-7200|Nov-2023-7200|Dec-2023-7200', 'Jan-2023-2800|Feb-2023-2800|Mar-2023-2800|Apr-2023-2800|May-2023-2800|Jun-2023-2800|July-2023-2800|Aug-2023-2800|Sep-2023-2800|Oct-2023-2800|Nov-2023-2800|Dec-2023-2800', 'Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', 'Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0'),
(2, 'Qualesce', 1, '', 'India', 'electricity', '', 'ABC', 'fixed', '', '2023-03-01', '2023-12-31', 45.00, '12,000', '12000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', NULL, NULL, NULL, NULL, 'A', 'Mar-2023-1000|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', NULL, NULL, NULL),
(3, 'Qualesce', 1, 'Qualesce-elec-00003', 'India', 'electricity', '', 'ELecc', 'fixed', '', '2023-03-01', '2023-12-31', 45.00, '120,000', '100,000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', '', NULL, NULL, '', 'A', 'Mar-2023-10000|Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', NULL, '--|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', '--|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0'),
(4, 'Qualesce', 1, 'Qualesce-elec-00004', 'India', 'electricity', '', 'ELecc', 'fixed', '', '2023-07-01', '2027-12-31', 45.00, '12,000', '12,000', '2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01,2026-1-01,2026-2-01,2026-3-01,2026-4-01,2026-5-01,2026-6-01,2026-7-01,2026-8-01,2026-9-01,2026-10-01,2026-11-01,2026-12-01,2027-1-01,2027-2-01,2027-3-01,2027-4-01,2027-5-01,2027-6-01,2027-7-01,2027-8-01,2027-9-01,2027-10-01,2027-11-01,2027-12-01', 'AUD', '', NULL, NULL, '', 'A', 'July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000|Jan-2026-1000|Feb-2026-1000|Mar-2026-1000|Apr-2026-1000|May-2026-1000|Jun-2026-1000|July-2026-1000|Aug-2026-1000|Sep-2026-1000|Oct-2026-1000|Nov-2026-1000|Dec-2026-1000|Jan-2027-1000|Feb-2027-1000|Mar-2027-1000|Apr-2027-1000|May-2027-1000|Jun-2027-1000|July-2027-1000|Aug-2027-1000|Sep-2027-1000|Oct-2027-1000|Nov-2027-1000|Dec-2027-1000', 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0|Jan-2026-0|Feb-2026-0|Mar-2026-0|Apr-2026-0|May-2026-0|Jun-2026-0|July-2026-0|Aug-2026-0|Sep-2026-0|Oct-2026-0|Nov-2026-0|Dec-2026-0|Jan-2027-0|Feb-2027-0|Mar-2027-0|Apr-2027-0|May-2027-0|Jun-2027-0|July-2027-0|Aug-2027-0|Sep-2027-0|Oct-2027-0|Nov-2027-0|Dec-2027-0', NULL, '--|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0|Jan-2026-0|Feb-2026-0|Mar-2026-0|Apr-2026-0|May-2026-0|Jun-2026-0|July-2026-0|Aug-2026-0|Sep-2026-0|Oct-2026-0|Nov-2026-0|Dec-2026-0|Jan-2027-0|Feb-2027-0|Mar-2027-0|Apr-2027-0|May-2027-0|Jun-2027-0|July-2027-0|Aug-2027-0|Sep-2027-0|Oct-2027-0|Nov-2027-0|Dec-2027-0', '--|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0|Jan-2026-0|Feb-2026-0|Mar-2026-0|Apr-2026-0|May-2026-0|Jun-2026-0|July-2026-0|Aug-2026-0|Sep-2026-0|Oct-2026-0|Nov-2026-0|Dec-2026-0|Jan-2027-0|Feb-2027-0|Mar-2027-0|Apr-2027-0|May-2027-0|Jun-2027-0|July-2027-0|Aug-2027-0|Sep-2027-0|Oct-2027-0|Nov-2027-0|Dec-2027-0'),
(5, 'Qualesce', 1, 'Qualesce-elec-00005', 'India', 'electricity', '', 'A', 'indexed', 'ASX', '2023-03-01', '2024-12-31', 0.00, '12,000', '12000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Month Ahead,Average Value', 'A', 'Mar-2023-1000|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000', 'Mar-2023-1000|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0', 'Mar-2023-100|Apr-2023-100|May-2023-100|Jun-2023-100|July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-100|Nov-2023-100|Dec-2023-100|Jan-2024-100|Feb-2024-100|Mar-2024-100|Apr-2024-100|May-2024-100|Jun-2024-100|July-2024-100|Aug-2024-100|Sep-2024-100|Oct-2024-100|Nov-2024-100|Dec-2024-100', 'Mar-2023-110|Apr-2023-110|May-2023-110|Jun-2023-110|July-2023-110|Aug-2023-110|Sep-2023-110|Oct-2023-110|Nov-2023-110|Dec-2023-110|Jan-2024-110|Feb-2024-110|Mar-2024-110|Apr-2024-110|May-2024-110|Jun-2024-110|July-2024-110|Aug-2024-110|Sep-2024-110|Oct-2024-110|Nov-2024-110|Dec-2024-110'),
(6, 'Qualesce', 1, 'Qualesce-elec-00006', 'India', 'electricity', '', 'ELec', 'indexed', 'ASX', '2023-07-01', '2025-12-31', 0.00, '12,000', '12000', '2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Month Ahead,Last Value', 'A', 'July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000', 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-150|Feb-2024-150|Mar-2024-150|Apr-2024-150|May-2024-150|Jun-2024-150|July-2024-150|Aug-2024-150|Sep-2024-150|Oct-2024-150|Nov-2024-150|Dec-2024-150|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-850|Feb-2024-850|Mar-2024-850|Apr-2024-850|May-2024-850|Jun-2024-850|July-2024-850|Aug-2024-850|Sep-2024-850|Oct-2024-850|Nov-2024-850|Dec-2024-850|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000', 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-100|Feb-2024-100|Mar-2024-100|Apr-2024-100|May-2024-100|Jun-2024-100|July-2024-100|Aug-2024-100|Sep-2024-100|Oct-2024-100|Nov-2024-100|Dec-2024-100|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-110|Feb-2024-110|Mar-2024-110|Apr-2024-110|May-2024-110|Jun-2024-110|July-2024-110|Aug-2024-110|Sep-2024-110|Oct-2024-110|Nov-2024-110|Dec-2024-110|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0'),
(7, 'Qualesce', 1, 'Qualesce-elec-00007', 'India', 'electricity', '', 'ELecc', 'indexed', 'ASX', '2023-07-01', '2025-12-31', 0.00, '12,000', '12000', '2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Month Ahead,Last Value', 'A', 'July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000', 'July-2023-3.3333333333333|Aug-2023-3.3333333333333|Sep-2023-3.3333333333333|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-996.66666666667|Aug-2023-996.66666666667|Sep-2023-996.66666666667|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000', 'July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0'),
(8, 'Qualesce', 1, 'Qualesce-elec-00008', 'India', 'electricity', '', 'ELecc', 'indexed', 'ASX', '2023-07-01', '2025-12-31', 0.00, '12,000', '12000', '2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Power(MW)', NULL, NULL, 'Month Ahead,Average Value', 'A', 'July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000', 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', NULL, 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0'),
(9, 'Qualesce', 1, 'Qualesce-elec-00009', 'India', 'electricity', '', 'ELecc', 'indexed', 'ASX', '2023-07-01', '2025-12-31', 0.00, '12,000', '12000', '2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Power(MW)', NULL, NULL, 'Month Ahead,Average Value', 'A', 'July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000', 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', NULL, 'July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-100|Nov-2023-100|Dec-2023-100|Jan-2024-100|Feb-2024-100|Mar-2024-100|Apr-2024-100|May-2024-100|Jun-2024-100|July-2024-100|Aug-2024-100|Sep-2024-100|Oct-2024-100|Nov-2024-100|Dec-2024-100|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-100|Nov-2023-100|Dec-2023-100|Jan-2024-120|Feb-2024-120|Mar-2024-120|Apr-2024-120|May-2024-120|Jun-2024-120|July-2024-120|Aug-2024-120|Sep-2024-120|Oct-2024-120|Nov-2024-120|Dec-2024-120|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0'),
(10, 'Qualesce', 1, 'Qualesce-elec-00010', 'India', 'electricity', '', 'ELecc', 'indexed', 'ASX', '2023-07-01', '2025-12-31', 0.00, '12,000', '12000', '2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Power(MW)', NULL, NULL, 'Month Ahead,Average Value', 'A', 'July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000', 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-14640|Feb-2024-14640|Mar-2024-14640|Apr-2024-14640|May-2024-14640|Jun-2024-14640|July-2024-14640|Aug-2024-14640|Sep-2024-14640|Oct-2024-14640|Nov-2024-14640|Dec-2024-14640|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024--13640|Feb-2024--13640|Mar-2024--13640|Apr-2024--13640|May-2024--13640|Jun-2024--13640|July-2024--13640|Aug-2024--13640|Sep-2024--13640|Oct-2024--13640|Nov-2024--13640|Dec-2024--13640|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000', 'July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-100|Nov-2023-100|Dec-2023-100|Jan-2024-100|Feb-2024-100|Mar-2024-100|Apr-2024-100|May-2024-100|Jun-2024-100|July-2024-100|Aug-2024-100|Sep-2024-100|Oct-2024-100|Nov-2024-100|Dec-2024-100|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-120|Aug-2023-120|Sep-2023-120|Oct-2023-120|Nov-2023-120|Dec-2023-120|Jan-2024-110|Feb-2024-110|Mar-2024-110|Apr-2024-110|May-2024-110|Jun-2024-110|July-2024-110|Aug-2024-110|Sep-2024-110|Oct-2024-110|Nov-2024-110|Dec-2024-110|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0'),
(11, 'Qualesce', 1, 'Qualesce-elec-00011', 'India', 'electricity', '', 'A', 'indexed', 'ASX', '2023-07-01', '2025-12-31', 0.00, '1,200,000', '1200000', '2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Power(MW)', NULL, NULL, 'Month Ahead,Last Value', 'A', 'July-2023-100000|Aug-2023-100000|Sep-2023-100000|Oct-2023-100000|Nov-2023-100000|Dec-2023-100000|Jan-2024-100000|Feb-2024-100000|Mar-2024-100000|Apr-2024-100000|May-2024-100000|Jun-2024-100000|July-2024-100000|Aug-2024-100000|Sep-2024-100000|Oct-2024-100000|Nov-2024-100000|Dec-2024-100000|Jan-2025-100000|Feb-2025-100000|Mar-2025-100000|Apr-2025-100000|May-2025-100000|Jun-2025-100000|July-2025-100000|Aug-2025-100000|Sep-2025-100000|Oct-2025-100000|Nov-2025-100000|Dec-2025-100000', 'July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-7320|Feb-2024-7320|Mar-2024-7320|Apr-2024-7320|May-2024-7320|Jun-2024-7320|July-2024-7320|Aug-2024-7320|Sep-2024-7320|Oct-2024-7320|Nov-2024-7320|Dec-2024-7320|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-100000|Aug-2023-100000|Sep-2023-100000|Oct-2023-100000|Nov-2023-100000|Dec-2023-100000|Jan-2024-92680|Feb-2024-92680|Mar-2024-92680|Apr-2024-92680|May-2024-92680|Jun-2024-92680|July-2024-92680|Aug-2024-92680|Sep-2024-92680|Oct-2024-92680|Nov-2024-92680|Dec-2024-92680|Jan-2025-100000|Feb-2025-100000|Mar-2025-100000|Apr-2025-100000|May-2025-100000|Jun-2025-100000|July-2025-100000|Aug-2025-100000|Sep-2025-100000|Oct-2025-100000|Nov-2025-100000|Dec-2025-100000', 'July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-100|Nov-2023-100|Dec-2023-100|Jan-2024-100|Feb-2024-100|Mar-2024-100|Apr-2024-100|May-2024-100|Jun-2024-100|July-2024-100|Aug-2024-100|Sep-2024-100|Oct-2024-100|Nov-2024-100|Dec-2024-100|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'July-2023-110|Aug-2023-110|Sep-2023-110|Oct-2023-110|Nov-2023-110|Dec-2023-110|Jan-2024-120|Feb-2024-120|Mar-2024-120|Apr-2024-120|May-2024-120|Jun-2024-120|July-2024-120|Aug-2024-120|Sep-2024-120|Oct-2024-120|Nov-2024-120|Dec-2024-120|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0'),
(12, 'Qualesce', 1, 'Qualesce-elec-00012', 'India', 'electricity', '', 'ELec', 'fixed', '', '2023-03-01', '2023-12-31', 45.00, '120,000', '120000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', NULL, NULL, NULL, NULL, 'A', 'Mar-2023-10000|Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', NULL, NULL, NULL),
(13, 'Testing', 2, 'test1-elec-00001', 'India', 'electricity', '', 'elec', 'fixed', '', '2023-03-01', '2023-12-31', 120.00, '12,000', '10000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', NULL, NULL, NULL, NULL, 'A', 'Mar-2023-1000|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', NULL, '--', '--'),
(14, 'Testing', 2, 'test1-elec-00002', 'India', 'electricity', '', 'elce', 'fixed', '', '2023-01-01', '2025-12-31', 12.00, '120,000', '120000', '2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'PLN', NULL, NULL, NULL, NULL, 'A', 'Jan-2023-9000|Feb-2023-10000|Mar-2023-11000|Apr-2023-10000|May-2023-10000|Jun-2023-12000|July-2023-10000|Aug-2023-8000|Sep-2023-11000|Oct-2023-9000|Nov-2023-10000|Dec-2023-10000|Jan-2024-9000|Feb-2024-10000|Mar-2024-11000|Apr-2024-10000|May-2024-10000|Jun-2024-12000|July-2024-10000|Aug-2024-8000|Sep-2024-11000|Oct-2024-9000|Nov-2024-10000|Dec-2024-10000|Jan-2025-9000|Feb-2025-10000|Mar-2025-11000|Apr-2025-10000|May-2025-10000|Jun-2025-12000|July-2025-10000|Aug-2025-8000|Sep-2025-11000|Oct-2025-9000|Nov-2025-10000|Dec-2025-10000', 'Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', NULL, '--', '--'),
(15, 'Testing', 2, 'test1-elec-00003', 'India', 'electricity', '', 'ELec', 'indexed', 'ASX', '2023-01-01', '2025-12-31', 0.00, '12,000', '12000', '2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'EUR', 'Consumption(MWh)', NULL, NULL, 'Day Ahead,Spot Daily Market', 'A', 'Jan-2023-1000|Feb-2023-1000|Mar-2023-1000|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000|Jan-2025-1000|Feb-2025-1000|Mar-2025-1000|Apr-2025-1000|May-2025-1000|Jun-2025-1000|July-2025-1000|Aug-2025-1000|Sep-2025-1000|Oct-2025-1000|Nov-2025-1000|Dec-2025-1000', 'Jan-2023-100|Feb-2023-100|Mar-2023-100|Apr-2023-233.33333333333|May-2023-233.33333333333|Jun-2023-233.33333333333|July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-140|Nov-2023-140|Dec-2023-140|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-900|Feb-2025-900|Mar-2025-900|Apr-2025-900|May-2025-900|Jun-2025-900|July-2025-900|Aug-2025-900|Sep-2025-900|Oct-2025-900|Nov-2025-900|Dec-2025-900', 'Jan-2023-900|Feb-2023-900|Mar-2023-900|Apr-2023-766.66666666667|May-2023-766.66666666667|Jun-2023-766.66666666667|July-2023-900|Aug-2023-900|Sep-2023-900|Oct-2023-860|Nov-2023-860|Dec-2023-860|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000|Jan-2025-100|Feb-2025-100|Mar-2025-100|Apr-2025-100|May-2025-100|Jun-2025-100|July-2025-100|Aug-2025-100|Sep-2025-100|Oct-2025-100|Nov-2025-100|Dec-2025-100', 'Jan-2023-100|Feb-2023-100|Mar-2023-100|Apr-2023-100|May-2023-100|Jun-2023-100|July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-100|Nov-2023-100|Dec-2023-100|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-100|Feb-2025-100|Mar-2025-100|Apr-2025-100|May-2025-100|Jun-2025-100|July-2025-100|Aug-2025-100|Sep-2025-100|Oct-2025-100|Nov-2025-100|Dec-2025-100', 'Jan-2023-120|Feb-2023-120|Mar-2023-120|Apr-2023-120|May-2023-120|Jun-2023-120|July-2023-120|Aug-2023-120|Sep-2023-120|Oct-2023-120|Nov-2023-120|Dec-2023-120|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-120|Feb-2025-120|Mar-2025-120|Apr-2025-120|May-2025-120|Jun-2025-120|July-2025-120|Aug-2025-120|Sep-2025-120|Oct-2025-120|Nov-2025-120|Dec-2025-120'),
(16, 'Testing', 2, 'test1-gas-00004', 'India', 'natural gas', 'MWh_GE', 'naturalgas', 'indexed', 'CEEGEX', '2023-03-01', '2025-12-31', 0.00, '120,000', '120,000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Day Ahead,Spot Daily Market', 'A', 'Mar-2023-10000|Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000|Jan-2024-10000|Feb-2024-10000|Mar-2024-10000|Apr-2024-10000|May-2024-10000|Jun-2024-10000|July-2024-10000|Aug-2024-10000|Sep-2024-10000|Oct-2024-10000|Nov-2024-10000|Dec-2024-10000|Jan-2025-10000|Feb-2025-10000|Mar-2025-10000|Apr-2025-10000|May-2025-10000|Jun-2025-10000|July-2025-10000|Aug-2025-10000|Sep-2025-10000|Oct-2025-10000|Nov-2025-10000|Dec-2025-10000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'Mar-2023-9000|Apr-2023-10000|May-2023-11000|Jun-2023-10000|July-2023-12000|Aug-2023-10000|Sep-2023-10000|Oct-2023-8000|Nov-2023-10000|Dec-2023-10000|Jan-2024-800|Feb-2024-800|Mar-2024-720|Apr-2024-800|May-2024-880|Jun-2024-800|July-2024-960|Aug-2024-800|Sep-2024-800|Oct-2024-640|Nov-2024-800|Dec-2024-800|Jan-2025-10000|Feb-2025-10000|Mar-2025-9000|Apr-2025-10000|May-2025-11000|Jun-2025-10000|July-2025-12000|Aug-2025-10000|Sep-2025-10000|Oct-2025-8000|Nov-2025-10000|Dec-2025-10000|Jan-2026-10000|Feb-2026-10000|Mar-2026-9000|Apr-2026-10000|May-2026-11000|Jun-2026-10000|July-2026-12000|Aug-2026-10000|Sep-2026-10000|Oct-2026-8000|Nov-2026-10000|Dec-2026-10000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0|Jan-2026-0|Feb-2026-0|Mar-2026-0|Apr-2026-0|May-2026-0|Jun-2026-0|July-2026-0|Aug-2026-0|Sep-2026-0|Oct-2026-0|Nov-2026-0|Dec-2026-0', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0|Jan-2026-0|Feb-2026-0|Mar-2026-0|Apr-2026-0|May-2026-0|Jun-2026-0|July-2026-0|Aug-2026-0|Sep-2026-0|Oct-2026-0|Nov-2026-0|Dec-2026-0'),
(17, 'Testing', 2, 'test1-elec-00005', 'India', 'electricity', '', 'ELec', 'indexed', 'ASX', '2023-01-01', '2023-12-31', 0.00, '12,000', '12000', '2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', 'Power(MW)', NULL, NULL, 'Day Ahead,Spot Daily Market', 'A', 'Jan-2023-1000|Feb-2023-1000|Mar-2023-1000|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000', 'Jan-2023-7300|Feb-2023-7300|Mar-2023-7300|Apr-2023-7300|May-2023-7300|Jun-2023-14500|July-2023-7300|Aug-2023-7300|Sep-2023-7300|Oct-2023-9508|Nov-2023-9508|Dec-2023-9508', 'Jan-2023--6300|Feb-2023--6300|Mar-2023--6300|Apr-2023--6300|May-2023--6300|Jun-2023--13500|July-2023--6300|Aug-2023--6300|Sep-2023--6300|Oct-2023--8508|Nov-2023--8508|Dec-2023--8508', 'Jan-2023-100|Feb-2023-100|Mar-2023-|Apr-2023-|May-2023-|Jun-2023-|July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-', 'Jan-2023-120|Feb-2023-120|Mar-2023-|Apr-2023-|May-2023-|Jun-2023-|July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-'),
(18, 'Qualesce INDIA', 3, 'Qualesce-elec-00001', 'Andorra', 'electricity', '', 'ELecc', 'indexed', 'EEX/Italy', '2023-03-01', '2023-12-31', 0.00, '12,000', '10000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'USD', 'Consumption(MWh)', NULL, NULL, 'Month Ahead,Average Value', 'A', 'Mar-2023-2000|Apr-2023-1200|May-2023-1000|Jun-2023-800|July-2023-500|Aug-2023-500|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', NULL, 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0'),
(19, 'Qualesce INDIA', 3, 'Qualesce-elec-00002', 'Andorra', 'electricity', '', 'ELec', 'indexed', 'ASX', '2023-03-01', '2024-12-31', 0.00, '12,000', '12000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Day Ahead,Spot Daily Market', 'A', 'Mar-2023-1000|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000', 'Mar-2023-3.3333333333333|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0', 'Mar-2023-996.66666666667|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000|Jan-2024-1000|Feb-2024-1000|Mar-2024-1000|Apr-2024-1000|May-2024-1000|Jun-2024-1000|July-2024-1000|Aug-2024-1000|Sep-2024-1000|Oct-2024-1000|Nov-2024-1000|Dec-2024-1000', 'Mar-2023-100|Apr-2023-100|May-2023-100|Jun-2023-100|July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-100|Nov-2023-100|Dec-2023-100|Jan-2024-100|Feb-2024-100|Mar-2024-100|Apr-2024-100|May-2024-100|Jun-2024-100|July-2024-100|Aug-2024-100|Sep-2024-100|Oct-2024-100|Nov-2024-100|Dec-2024-100', 'Mar-2023-120|Apr-2023-120|May-2023-120|Jun-2023-120|July-2023-120|Aug-2023-120|Sep-2023-120|Oct-2023-120|Nov-2023-120|Dec-2023-120|Jan-2024-110|Feb-2024-110|Mar-2024-110|Apr-2024-110|May-2024-110|Jun-2024-110|July-2024-110|Aug-2024-110|Sep-2024-110|Oct-2024-110|Nov-2024-110|Dec-2024-110'),
(20, 'Qualesce INDIA', 3, 'Qualesce-elec-00003', 'Andorra', 'electricity', '', 'Power', 'fixed', '', '2023-03-01', '2023-12-31', 45.00, '12,000', '12000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', NULL, NULL, NULL, NULL, 'A', 'Mar-2023-1000|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', NULL, '--', '--'),
(21, 'Qualesce INDIA', 3, 'Qualesce-elec-00004', 'Andorra', 'electricity', '', 'IndexElectricity1', 'indexed', 'ASX', '2023-03-01', '2025-12-31', 0.00, '120,000', '120000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Day Ahead,Spot Average for month', 'A', 'Mar-2023-10000|Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000|Jan-2024-10000|Feb-2024-10000|Mar-2024-10000|Apr-2024-10000|May-2024-10000|Jun-2024-10000|July-2024-10000|Aug-2024-10000|Sep-2024-10000|Oct-2024-10000|Nov-2024-10000|Dec-2024-10000|Jan-2025-10000|Feb-2025-10000|Mar-2025-10000|Apr-2025-10000|May-2025-10000|Jun-2025-10000|July-2025-10000|Aug-2025-10000|Sep-2025-10000|Oct-2025-10000|Nov-2025-10000|Dec-2025-10000', 'Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', NULL, 'Mar-2023-110|Apr-2023-110|May-2023-110|Jun-2023-110|July-2023-110|Aug-2023-110|Sep-2023-110|Oct-2023-110|Nov-2023-110|Dec-2023-110|Jan-2024-120|Feb-2024-120|Mar-2024-120|Apr-2024-120|May-2024-120|Jun-2024-120|July-2024-120|Aug-2024-120|Sep-2024-120|Oct-2024-120|Nov-2024-120|Dec-2024-120|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'Mar-2023-120|Apr-2023-120|May-2023-120|Jun-2023-120|July-2023-120|Aug-2023-120|Sep-2023-120|Oct-2023-120|Nov-2023-120|Dec-2023-120|Jan-2024-150|Feb-2024-150|Mar-2024-150|Apr-2024-150|May-2024-150|Jun-2024-150|July-2024-150|Aug-2024-150|Sep-2024-150|Oct-2024-150|Nov-2024-150|Dec-2024-150|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0'),
(22, 'TestParent', 4, 'TestClient-elec-00001', 'India', 'electricity', '', 'Supplier1', 'indexed', 'ASX', '2023-03-01', '2025-12-31', 0.00, '120,000', '120000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Day Ahead,Spot Average for month', 'A', 'Mar-2023-10000|Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000|Jan-2024-10000|Feb-2024-10000|Mar-2024-10000|Apr-2024-10000|May-2024-10000|Jun-2024-10000|July-2024-10000|Aug-2024-10000|Sep-2024-10000|Oct-2024-10000|Nov-2024-10000|Dec-2024-10000|Jan-2025-10000|Feb-2025-10000|Mar-2025-10000|Apr-2025-10000|May-2025-10000|Jun-2025-10000|July-2025-10000|Aug-2025-10000|Sep-2025-10000|Oct-2025-10000|Nov-2025-10000|Dec-2025-10000', 'Mar-2023-1000|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-2000|Nov-2023-2000|Dec-2023-2000|Jan-2024-2000|Feb-2024-2000|Mar-2024-2000|Apr-2024-2000|May-2024-2000|Jun-2024-4000|July-2024-2000|Aug-2024-2000|Sep-2024-2000|Oct-2024-4000|Nov-2024-4000|Dec-2024-4000|Jan-2025-0|Feb-2025-0', 'Mar-2023-9000|Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-8000|Nov-2023-8000|Dec-2023-8000|Jan-2024-8000|Feb-2024-8000|Mar-2024-8000|Apr-2024-8000|May-2024-8000|Jun-2024-6000|July-2024-8000|Aug-2024-8000|Sep-2024-8000|Oct-2024-6000|Nov-2024-6000|Dec-2024-6000|Jan-2025-10000|Feb-2025-10000|Mar-2025-9000|Apr-2025-9000|May-2025-9000|Jun-2025-9000|July-2025-9000|Aug-2025-9000|Sep-2025-9000|Oct-2025-9000|Nov-2025-9000|Dec-2025-9000', 'Mar-2023-|Apr-2023-|May-2023-|Jun-2023-|July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-|Jan-2024-100|Feb-2024-100|Mar-2024-100|Apr-2024-100|May-2024-100|Jun-2024-100|July-2024-100|Aug-2024-100|Sep-2024-100|Oct-2024-100|Nov-2024-100|Dec-2024-100|Jan-2025-100|Feb-2025-100|Mar-2025-100|Apr-2025-100|May-2025-100|Jun-2025-100|July-2025-100|Aug-2025-100|Sep-2025-100|Oct-2025-100|Nov-2025-100|Dec-2025-100', 'Mar-2023-|Apr-2023-|May-2023-|Jun-2023-|July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-|Jan-2024-110|Feb-2024-110|Mar-2024-110|Apr-2024-110|May-2024-110|Jun-2024-110|July-2024-110|Aug-2024-110|Sep-2024-110|Oct-2024-110|Nov-2024-110|Dec-2024-110|Jan-2025-110|Feb-2025-110|Mar-2025-110|Apr-2025-110|May-2025-110|Jun-2025-110|July-2025-110|Aug-2025-110|Sep-2025-110|Oct-2025-110|Nov-2025-110|Dec-2025-110'),
(23, 'TestParent', 4, 'TestClient-elec-00002', 'India', 'electricity', '', 'Supplier2', 'indexed', 'ASX', '2023-03-01', '2025-12-31', 0.00, '120,000', '120000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Month Ahead,Last Value', 'A', 'Mar-2023-10000|Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000|Jan-2024-10000|Feb-2024-10000|Mar-2024-10000|Apr-2024-10000|May-2024-10000|Jun-2024-10000|July-2024-10000|Aug-2024-10000|Sep-2024-10000|Oct-2024-10000|Nov-2024-10000|Dec-2024-10000|Jan-2025-10000|Feb-2025-10000|Mar-2025-10000|Apr-2025-10000|May-2025-10000|Jun-2025-10000|July-2025-10000|Aug-2025-10000|Sep-2025-10000|Oct-2025-10000|Nov-2025-10000|Dec-2025-10000', 'Mar-2023-133.33333333333|Apr-2023-0|May-2023-0|Jun-2023-2000|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0', 'Mar-2023-9866.6666666667|Apr-2023-10000|May-2023-10000|Jun-2023-8000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000|Jan-2024-10000|Feb-2024-10000|Mar-2024-10000|Apr-2024-10000|May-2024-10000|Jun-2024-10000|July-2024-10000|Aug-2024-10000|Sep-2024-10000|Oct-2024-10000|Nov-2024-10000|Dec-2024-10000|Jan-2025-10000|Feb-2025-10000|Mar-2025-9866.6666666667|Apr-2025-9866.6666666667|May-2025-9866.6666666667|Jun-2025-9866.6666666667|July-2025-9866.6666666667|Aug-2025-9866.6666666667|Sep-2025-9866.6666666667|Oct-2025-9866.6666666667|Nov-2025-9866.6666666667|Dec-2025-9866.6666666667', 'Mar-2023-100|Apr-2023-100|May-2023-100|Jun-2023-100|July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-100|Nov-2023-100|Dec-2023-100|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'Mar-2023-110|Apr-2023-110|May-2023-110|Jun-2023-110|July-2023-110|Aug-2023-110|Sep-2023-110|Oct-2023-110|Nov-2023-110|Dec-2023-110|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0'),
(24, 'TestParent', 4, 'TestClient-elec-00003', 'India', 'electricity', '', 'power', 'indexed', 'ASX', '2023-03-01', '2025-12-31', 0.00, '1,200,000', '1200000', '2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01,2024-10-01,2024-11-01,2024-12-01,2025-1-01,2025-2-01,2025-3-01,2025-4-01,2025-5-01,2025-6-01,2025-7-01,2025-8-01,2025-9-01,2025-10-01,2025-11-01,2025-12-01', 'AUD', 'Power(MW)', NULL, NULL, 'Day Ahead,Spot Average for month', 'A', 'Mar-2023-100000|Apr-2023-100000|May-2023-100000|Jun-2023-100000|July-2023-100000|Aug-2023-100000|Sep-2023-100000|Oct-2023-100000|Nov-2023-100000|Dec-2023-100000|Jan-2024-100000|Feb-2024-100000|Mar-2024-100000|Apr-2024-100000|May-2024-100000|Jun-2024-100000|July-2024-100000|Aug-2024-100000|Sep-2024-100000|Oct-2024-100000|Nov-2024-100000|Dec-2024-100000|Jan-2025-100000|Feb-2025-100000|Mar-2025-100000|Apr-2025-100000|May-2025-100000|Jun-2025-100000|July-2025-100000|Aug-2025-100000|Sep-2025-100000|Oct-2025-100000|Nov-2025-100000|Dec-2025-100000', 'Mar-2023-0|Apr-2023-0|May-2023-3720|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0', 'Mar-2023-100000|Apr-2023-100000|May-2023-96280|Jun-2023-100000|July-2023-100000|Aug-2023-100000|Sep-2023-100000|Oct-2023-100000|Nov-2023-100000|Dec-2023-100000|Jan-2024-100000|Feb-2024-100000|Mar-2024-100000|Apr-2024-100000|May-2024-100000|Jun-2024-100000|July-2024-100000|Aug-2024-100000|Sep-2024-100000|Oct-2024-100000|Nov-2024-100000|Dec-2024-100000|Jan-2025-100000|Feb-2025-100000|Mar-2025-100000|Apr-2025-100000|May-2025-100000|Jun-2025-100000|July-2025-100000|Aug-2025-100000|Sep-2025-100000|Oct-2025-100000|Nov-2025-100000|Dec-2025-100000', 'Mar-2023-|Apr-2023-|May-2023-|Jun-2023-|July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0', 'Mar-2023-|Apr-2023-|May-2023-|Jun-2023-|July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0|Oct-2024-0|Nov-2024-0|Dec-2024-0|Jan-2025-0|Feb-2025-0|Mar-2025-0|Apr-2025-0|May-2025-0|Jun-2025-0|July-2025-0|Aug-2025-0|Sep-2025-0|Oct-2025-0|Nov-2025-0|Dec-2025-0'),
(25, 'TestParent', 4, 'TestClient-elec-00004', 'India', 'electricity', '', 'First', 'indexed', 'ASX', '2023-04-01', '2023-12-31', 0.00, '120,000', '120000', '2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Month Ahead,Last Value', 'A', 'Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000', 'Apr-2023-2000|May-2023-2000|Jun-2023-2000|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', 'Apr-2023-8000|May-2023-8000|Jun-2023-8000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000', 'Apr-2023-110|May-2023-110|Jun-2023-110|July-2023-110|Aug-2023-110|Sep-2023-110|Oct-2023-110|Nov-2023-110|Dec-2023-110', 'Apr-2023-120|May-2023-120|Jun-2023-120|July-2023-120|Aug-2023-120|Sep-2023-120|Oct-2023-120|Nov-2023-120|Dec-2023-120'),
(26, 'TestParent2', 5, 'TestClient2-elec-00001', 'India', 'electricity', '', 'Qualesce1', 'indexed', 'ASX', '2023-01-01', '2023-12-31', 0.00, '120,000', '120000', '2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Day Ahead,Spot Average for month', 'A', 'Jan-2023-10000|Feb-2023-10000|Mar-2023-10000|Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000', 'Jan-2023-1000|Feb-2023-1000|Mar-2023-1000|Apr-2023-1000|May-2023-1000|Jun-2023-1000|July-2023-1000|Aug-2023-1000|Sep-2023-1000|Oct-2023-1000|Nov-2023-1000|Dec-2023-1000', 'Jan-2023-9000|Feb-2023-9000|Mar-2023-9000|Apr-2023-9000|May-2023-9000|Jun-2023-9000|July-2023-9000|Aug-2023-9000|Sep-2023-9000|Oct-2023-9000|Nov-2023-9000|Dec-2023-9000', 'Jan-2023-100|Feb-2023-100|Mar-2023-|Apr-2023-|May-2023-|Jun-2023-|July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-', 'Jan-2023-120|Feb-2023-120|Mar-2023-|Apr-2023-|May-2023-|Jun-2023-|July-2023-|Aug-2023-|Sep-2023-|Oct-2023-|Nov-2023-|Dec-2023-'),
(27, 'TestParent', 4, 'TestClient-elec-00005', 'India', 'electricity', '', 'GGc', 'indexed', 'ASX', '2023-04-01', '2023-12-31', 0.00, '120,000', '120000', '2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01', 'AUD', 'Consumption(MWh)', NULL, NULL, 'Day Ahead,Spot Average for month', 'A', 'Apr-2023-10000|May-2023-10000|Jun-2023-10000|July-2023-10000|Aug-2023-10000|Sep-2023-10000|Oct-2023-10000|Nov-2023-10000|Dec-2023-10000', 'Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', NULL, 'Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0', 'Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0');

-- --------------------------------------------------------

--
-- Table structure for table `nus_tradeperiods`
--

CREATE TABLE `nus_tradeperiods` (
  `tradePerId` int(11) NOT NULL,
  `supplierId` int(11) NOT NULL,
  `periodsId` varchar(128) NOT NULL,
  `clicktracnches` int(11) NOT NULL,
  `clicktranches` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nus_tradeperiods`
--

INSERT INTO `nus_tradeperiods` (`tradePerId`, `supplierId`, `periodsId`, `clicktracnches`, `clicktranches`) VALUES
(1, 1, 'Calendar Yearly', 4, '% consumption'),
(2, 5, 'Calendar Yearly', 4, '% consumption'),
(3, 5, 'Calendar Quarterly', 4, '#MWhs'),
(4, 5, 'Calendar Monthly', 4, '% consumption'),
(5, 6, 'Calendar Yearly', 4, '% consumption'),
(6, 7, 'Calendar Yearly', 5, '% consumption'),
(7, 7, 'Calendar Quarterly', 5, '#MWhs'),
(8, 7, 'Calendar Monthly', 5, '% consumption'),
(9, 8, 'Calendar Yearly', 4, ''),
(10, 8, 'Calendar Quarterly', 5, ''),
(11, 8, 'Calendar Monthly', 6, ''),
(12, 9, 'Calendar Yearly', 4, ''),
(13, 9, 'Calendar Quarterly', 5, ''),
(14, 9, 'Calendar Monthly', 6, ''),
(15, 10, 'Calendar Yearly', 4, ''),
(16, 10, 'Calendar Quarterly', 5, ''),
(17, 10, 'Calendar Monthly', 6, ''),
(18, 11, 'Calendar Yearly', 4, ''),
(19, 11, 'Calendar Quarterly', 5, ''),
(20, 11, 'Calendar Monthly', 5, ''),
(21, 15, 'Calendar Yearly', 2, '% consumption'),
(22, 15, 'Calendar Quarterly', 2, '#MWhs'),
(23, 15, 'Calendar Monthly', 2, '% consumption'),
(27, 16, 'Calendar Yearly', 1, '% consumption'),
(28, 16, 'Calendar Quarterly', 1, '#MWhs'),
(29, 16, 'Calendar Monthly', 1, '% consumption'),
(30, 17, 'Calendar Yearly', 1, ''),
(31, 17, 'Calendar Quarterly', 2, ''),
(32, 17, 'Calendar Monthly', 2, ''),
(33, 18, 'Calendar Yearly', 4, '% consumption'),
(34, 18, 'Calendar Quarterly', 5, '#MWhs'),
(35, 19, 'Calendar Yearly', 4, '% consumption'),
(36, 19, 'Calendar Quarterly', 5, '#MWhs'),
(37, 21, 'Calendar Yearly', 4, '% consumption'),
(38, 21, 'Calendar Quarterly', 4, '% consumption'),
(39, 21, 'Calendar Monthly', 4, '% consumption'),
(40, 22, 'Calendar Yearly', 4, '% consumption'),
(41, 22, 'Calendar Quarterly', 4, '% consumption'),
(42, 22, 'Calendar Monthly', 4, '% consumption'),
(43, 23, 'Calendar Yearly', 4, '% consumption'),
(44, 23, 'Calendar Quarterly', 5, '#MWhs'),
(45, 23, 'Calendar Monthly', 5, '% consumption'),
(46, 24, 'Calendar Yearly', 4, ''),
(47, 24, 'Calendar Quarterly', 5, ''),
(48, 24, 'Calendar Monthly', 5, ''),
(49, 25, 'Calendar Quarterly', 4, '% consumption'),
(50, 26, 'Calendar Yearly', 4, '% consumption'),
(51, 26, 'Calendar Quarterly', 4, '% consumption'),
(52, 27, 'Calendar Yearly', 4, '% consumption');

-- --------------------------------------------------------

--
-- Table structure for table `nus_trade_periods_list`
--

CREATE TABLE `nus_trade_periods_list` (
  `tPeriodsId` int(11) NOT NULL,
  `periodsName` varchar(128) NOT NULL,
  `addedOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parentcompanydata`
--

CREATE TABLE `parentcompanydata` (
  `id` int(11) NOT NULL,
  `parentcompany` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parentcompanydata`
--

INSERT INTO `parentcompanydata` (`id`, `parentcompany`) VALUES
(1, 'Qualesce'),
(3, 'Qualesce INDIA'),
(2, 'Testing'),
(4, 'TestParent'),
(5, 'TestParent2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clientcompanydata`
--
ALTER TABLE `clientcompanydata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enter_trade`
--
ALTER TABLE `enter_trade`
  ADD PRIMARY KEY (`tradeId`);

--
-- Indexes for table `nususerdata`
--
ALTER TABLE `nususerdata`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`emailId`),
  ADD UNIQUE KEY `username_2` (`username`,`emailId`),
  ADD UNIQUE KEY `username_3` (`username`),
  ADD UNIQUE KEY `emailId` (`emailId`);

--
-- Indexes for table `nus_calendermonth`
--
ALTER TABLE `nus_calendermonth`
  ADD PRIMARY KEY (`monthId`);

--
-- Indexes for table `nus_calenderquarter`
--
ALTER TABLE `nus_calenderquarter`
  ADD PRIMARY KEY (`querterid`);

--
-- Indexes for table `nus_calenderyear`
--
ALTER TABLE `nus_calenderyear`
  ADD PRIMARY KEY (`calenderId`);

--
-- Indexes for table `nus_countries`
--
ALTER TABLE `nus_countries`
  ADD PRIMARY KEY (`countryId`);

--
-- Indexes for table `nus_currencies`
--
ALTER TABLE `nus_currencies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `currencies` (`currencies`);

--
-- Indexes for table `nus_electricity_index`
--
ALTER TABLE `nus_electricity_index`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `indexlist` (`indexlist`);

--
-- Indexes for table `nus_naturalgas_index`
--
ALTER TABLE `nus_naturalgas_index`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `indexlist` (`indexlist`);

--
-- Indexes for table `nus_pricing_mechanisam`
--
ALTER TABLE `nus_pricing_mechanisam`
  ADD PRIMARY KEY (`priMechId`);

--
-- Indexes for table `nus_season`
--
ALTER TABLE `nus_season`
  ADD PRIMARY KEY (`seasonId`);

--
-- Indexes for table `nus_supply_contract`
--
ALTER TABLE `nus_supply_contract`
  ADD PRIMARY KEY (`supplierId`);

--
-- Indexes for table `nus_tradeperiods`
--
ALTER TABLE `nus_tradeperiods`
  ADD PRIMARY KEY (`tradePerId`);

--
-- Indexes for table `nus_trade_periods_list`
--
ALTER TABLE `nus_trade_periods_list`
  ADD PRIMARY KEY (`tPeriodsId`);

--
-- Indexes for table `parentcompanydata`
--
ALTER TABLE `parentcompanydata`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `parentcompany` (`parentcompany`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clientcompanydata`
--
ALTER TABLE `clientcompanydata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `enter_trade`
--
ALTER TABLE `enter_trade`
  MODIFY `tradeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `nususerdata`
--
ALTER TABLE `nususerdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `nus_calendermonth`
--
ALTER TABLE `nus_calendermonth`
  MODIFY `monthId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=437;

--
-- AUTO_INCREMENT for table `nus_calenderquarter`
--
ALTER TABLE `nus_calenderquarter`
  MODIFY `querterid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=170;

--
-- AUTO_INCREMENT for table `nus_calenderyear`
--
ALTER TABLE `nus_calenderyear`
  MODIFY `calenderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `nus_currencies`
--
ALTER TABLE `nus_currencies`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `nus_naturalgas_index`
--
ALTER TABLE `nus_naturalgas_index`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `nus_season`
--
ALTER TABLE `nus_season`
  MODIFY `seasonId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nus_supply_contract`
--
ALTER TABLE `nus_supply_contract`
  MODIFY `supplierId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `nus_tradeperiods`
--
ALTER TABLE `nus_tradeperiods`
  MODIFY `tradePerId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `nus_trade_periods_list`
--
ALTER TABLE `nus_trade_periods_list`
  MODIFY `tPeriodsId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parentcompanydata`
--
ALTER TABLE `parentcompanydata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
