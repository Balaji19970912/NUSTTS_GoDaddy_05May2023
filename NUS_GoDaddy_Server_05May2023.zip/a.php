<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<section class="sec1Container">
        <div class="sec1Wrapper">
            <div class="parentContainer">
                <br>
                <h2>Add user</h2>
                <div class="close-btn" onclick='window.history.go(-1);'>&times;</div>
                <br>
                <hr color="#d2ddec">
                <form onsubmit="return checkpasswordlength()" action="postinviteuser.php" method="POST" class="parentAddForm">

                    <label class="userdata">User name</label>
                    <input autocomplete="off" type="text" name="username" class="userNames" placeholder="Enter username"  required>

                    <label class="emaildata">Enter Email</label>
                    <input autocomplete="off" type="text" name="emailId" class="emailiddata"  placeholder="Enter email"  required>
                    
                    <label class="role">Role</label>
            
                    <select onchange="ChangeDropdowns(this.value)" id="role" class="selecting" name="role">
                        <option value="*" >Select an option</option>
                        <option value="Admin"  >Admin</option>
                        <option value="NUS Manager"  >NUS Manager</option>
                        <option value="NUS User"  >NUS User</option>
                        <option value="Parent company">Parent company</option>
                        <option value="Client company">Client company</option>
                    </select>
                    <div class = "userform"  id='showunit' style="display:none" >
                    <label class="roleid">Parent company</label>
                   
                        <select id="showunit" name="parentcompany" id="showunit"  class="roleparent">
                            <option disabled selected>Select a parent company</option>
                             

<?php
include "dbconn.php";
                    $getparent =array();
                    $getparentdetails = "SELECT * FROM parentcompanydata";
                    $results = $conn->query($getparentdetails);
                        if ($results->num_rows > 0) {
                            while($row = $results->fetch_assoc()) {
                                $getparent[] = $row;
                            }
                        }
                       
                        foreach ($getparent as $key => $valueparent) {
                          
                          ?>
                            <option value="<?=$valueparent['parentcompany']?>"><?=$valueparent['parentcompany']?></option>
                            
                        <?php
                        }
                        ?>
                        </select>
                    </div>
                    
<script>
    function ChangeDropdowns() {
        const dropDown = document.getElementById('role').value;
        const div = document.getElementById('show');
        const div1 = document.getElementById('showunit');

        console.log('Inside Changedropdown client');
        
        console.log(dropDown)
        if(dropDown == "Client company") {
            div.style.display = 'block';
            div1.style.display = 'block';
        }
        else if(dropDown == "Parent company") {
            div.style.display = 'none';
            div1.style.display = 'block';
        }
        else {
            div.style.display = 'none';
            div1.style.display = 'none';
        }
    }
</script>
                
</body>
</html>