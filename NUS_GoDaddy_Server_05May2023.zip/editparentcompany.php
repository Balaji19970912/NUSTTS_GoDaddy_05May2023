<?php include 'dbconn.php';
session_start();
	 $sql = "UPDATE parentcompanydata SET parentcompany ='".$_POST['parentcompany']."' WHERE id=".$_POST['parentid']."";
     $conn->query($sql);
     $_SESSION['updateparent'] = time();
     header('location:addcompany.php');
?>